/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapplication;
import java.util.*;
import java.util.regex.*;
/**
 *
 * @author mshiz
 */


    /**
     * @param args the command line arguments
     */
    

class User {
    private String username;
    private String password;
    private String phoneNumber;

    public User(String username, String password, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public boolean checkPassword(String password) {
        return this.password.equals(password);
    }

    public static boolean isValidUsername(String username) {
        return username.matches(".*_.*") && username.length() <= 5;
    }

    public static boolean isValidPassword(String password) {
        return password.length() >= 8 && password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") && password.matches(".*[!@#$%^&*].*");
    }

    public static boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("^\\+27\\d{9}$");
    }
}

class Message {
    private static int messageCount = 0;
    private String recipient;
    private String content;
    private String messageId;

    public Message(String recipient, String content) {
        this.recipient = recipient;
        this.content = content;
        this.messageId = generateMessageId();
        messageCount++;
    }

    private String generateMessageId() {
        return UUID.randomUUID().toString().substring(0, 10);
    }

    public String getMessageDetails() {
        return "Message ID: " + messageId + ", Recipient: " + recipient + ", Content: " + content;
    }

    public static int getMessageCount() {
        return messageCount;
    }
}

public class ChatApplication {
    private static List<User> users = new ArrayList<>();
    private static User loggedInUser = null;
    private static List<Message> messages = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Welcome to QuickChat!");
            System.out.println("1. Register\n2. Login\n3. Send Message\n4. Quit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    registerUser(scanner);
                    break;
                case 2:
                    loginUser(scanner);
                    break;
                case 3:
                    if (loggedInUser != null) {
                        sendMessage(scanner);
                    } else {
                        System.out.println("Please log in first.");
                    }
                    break;
                case 4:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }

    private static void registerUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter phone number (+27 format): ");
        String phoneNumber = scanner.nextLine();

        if (!User.isValidUsername(username)) {
            System.out.println("Username incorrectly formatted.");
            return;
        }
        if (!User.isValidPassword(password)) {
            System.out.println("Password does not meet complexity requirements.");
            return;
        }
        if (!User.isValidPhoneNumber(phoneNumber)) {
            System.out.println("Phone number incorrectly formatted.");
            return;
        }

        users.add(new User(username, password, phoneNumber));
        System.out.println("User successfully registered.");
    }

    private static void loginUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        for (User user : users) {
            if (user.getUsername().equals(username) && user.checkPassword(password)) {
                loggedInUser = user;
                System.out.println("Welcome back, " + username + "!");
                return;
            }
        }
        System.out.println("Username or password incorrect.");
    }

    private static void sendMessage(Scanner scanner) {
        System.out.print("Enter recipient phone number (+27 format): ");
        String recipient = scanner.nextLine();
        if (!User.isValidPhoneNumber(recipient)) {
            System.out.println("Recipient phone number incorrectly formatted.");
            return;
        }

        System.out.print("Enter message (max 250 characters): ");
        String messageContent = scanner.nextLine();
        if (messageContent.length() > 250) {
            System.out.println("Message exceeds 250 characters.");
            return;
        }

        Message message = new Message(recipient, messageContent);
        messages.add(message);
        System.out.println("Message sent!\n" + message.getMessageDetails());
    }
}

