import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    Login login = new Login();

    @Test
    public void testValidUsername() {
        assertTrue(login.checkUserName("abc_1"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(login.checkUserName("abcdef"));
    }

    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Passw0rd!"));
    }

    @Test
    public void testInvalidPassword_NoUppercase() {
        assertFalse(login.checkPasswordComplexity("password1!"));
    }

    @Test
    public void testInvalidPassword_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Password!"));
    }

    @Test
    public void testInvalidPassword_ShortLength() {
        assertFalse(login.checkPasswordComplexity("P1!a"));
    }

    @Test
    public void testValidPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testInvalidPhoneNumber_WrongFormat() {
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testRegisterSuccess() {
        String msg = login.registerUser("abc_1", "Passw0rd!", "John", "Doe", "+27831234567");
        assertEquals("Username and password successfully captured.", msg);
    }

    @Test
    public void testLoginSuccess() {
        login.registerUser("abc_1", "Passw0rd!", "John", "Doe", "+27831234567");
        assertTrue(login.loginUser("abc_1", "Passw0rd!"));
    }

    @Test
    public void testLoginFailure() {
        login.registerUser("abc_1", "Passw0rd!", "John", "Doe", "+27831234567");
        assertFalse(login.loginUser("wrong", "wrong"));
    }

    @Test
    public void testLoginStatusMessage_Success() {
        login.registerUser("abc_1", "Passw0rd!", "John", "Doe", "+27831234567");
        String message = login.returnLoginStatus("abc_1", "Passw0rd!");
        assertEquals("Welcome John, Doe it is great to see you again.", message);
    }

    @Test
    public void testLoginStatusMessage_Failure() {
        login.registerUser("abc_1", "Passw0rd!", "John", "Doe", "+27831234567");
        String message = login.returnLoginStatus("wrong", "wrong");
        assertEquals("Username or password incorrect, please try again.", message);
    }
}
