
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            Login login = new Login();
            
            System.out.println("=== User Registration ===");
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            
            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine();
            
            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine();
            
            System.out.print("Enter SA phone number (e.g. +27831234567): ");
            String phone = scanner.nextLine();
            
            String registrationMessage = login.registerUser(username, password, firstName, lastName, phone);
            System.out.println(registrationMessage);
            
            if (registrationMessage.equals("Username and password successfully captured.")) {
                System.out.println("\n=== User Login ===");
                System.out.print("Enter username: ");
                String loginUsername = scanner.nextLine();
                
                System.out.print("Enter password: ");
                String loginPassword = scanner.nextLine();
                
                System.out.println(login.returnLoginStatus(loginUsername, loginPassword));
            }
        }
    }
}
